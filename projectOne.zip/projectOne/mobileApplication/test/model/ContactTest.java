package model;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	//test creating contact
	@Test
	void testCreateContactSuccess() {
		Contact contact = new Contact("John", "Doe", "1234567890", "1 Main Street", "12345");
		assertTrue(contact != null);
		assertTrue(contact.getContactFirstName().equals("John"));
		assertTrue(contact.getContactLastName().equals("Doe"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("1 Main Street"));
		assertTrue(contact.getContactId().equals("12345"));
		}
	
	@Test
	void testCreateContactContactIdFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("John", "Doe", "1234567890", "1 Main Street", "11111111111");
		    });	
	}
	
	@Test
	void testCreateContactFirstNameFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("Johnjohnjohn", "Doe", "1234567890", "1 Main", "34567");
		    });	
	}
	
	@Test
	void testCreateContactLastNameFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("John", "Doedoedoedoe", "1234567890", "1 Main Street", "98765");
		    });	
	}
	
	@Test
	void testCreateContactAddressFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("John", "Doe", "1234567890", "1 Mainmainmainmainmainmain Street", "4802929112");
		    });	
	}
	
	@Test
	void testCreateContactNumberTooLongFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("John", "Doe", "888888999900", "1 Main Street", "34567");
		    });	
	}
	
	@Test
	void testCreateContactNumberTooShortFails() {
		  Assertions.assertThrows(IllegalArgumentException.class, () -> {
			  new Contact("John", "Doe", "8889999", "1 Main Street", "44567");
		    });	
	}
	
	
	//Test Contact Update
	
	@Test
	void testUpdateContactSuccess() {
		Contact contact = new Contact("Jane", "Doe", "1118889999", "1 Main Street", "56789");	
		
		contact.setContactAddress("2 Main Street");
		contact.setContactFirstName("Jenny");
		contact.setContactLastName("Johnson");
		contact.setContactPhoneNumber("9991118888");
		
		assertTrue(contact.getContactId().equals("56789"));
		assertTrue(contact.getContactFirstName().equals("Jenny"));
		assertTrue(contact.getContactLastName().equals("Johnson"));
		assertTrue(contact.getAddress().equals("2 Main Street"));
		assertTrue(contact.getPhoneNumber().equals("9991118888"));
	}
	
	@Test
	void testUpdateContactAddressFails() {
		Contact contact = new Contact("Jane", "Doe", "1118889999", "1 Main Street", "3456789");	
		assertFalse(contact.setContactAddress("1 Mainmainmainmainmainmain Street"));
	}
	
	@Test
	void testUpdateContactFirstNameFails() {
		Contact contact = new Contact("Jane", "Doe", "1118889999", "1 Main Street", "987654");	
		assertFalse(contact.setContactFirstName("Janejanejane"));
	}
	
	@Test
	void testUpdateContactLastNameFails() {
		Contact contact = new Contact("Jane", "Doe", "1119998888", "1 Main Street", "123678");	
		assertFalse(contact.setContactLastName("Doedoedoedoedoe"));
	}
	
	@Test
	void testUpdateContactNumberNotIntegerFails() {
		Contact contact = new Contact("Jane", "Doe", "1119998888", "1 main Street", "12345678");	
		assertFalse(contact.setContactPhoneNumber("abcdefghij"));
	}
	
	@Test
	void testUpdateContactNumberTooShortFails() {
		Contact contact = new Contact("Jane", "Doe", "1119998888", "1 main Street", "345678");	
		assertFalse(contact.setContactPhoneNumber("1234567"));
	}
	
	@Test
	void testUpdateContactNumberTooLongFails() {
		Contact contact = new Contact("Jane", "Doe", "1119998888", "1 main Street", "2345678");	
		assertFalse(contact.setContactPhoneNumber("11199988880"));
	}
	

}
	
	


