package model;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

@Test
void testCreateTaskSuccess() {
	Task task = new Task("12345", "chore", "this is a description" );
	assertTrue(task.getTaskId().equals("12345"));
	assertTrue(task.getTaskName().equals("chore"));
	assertTrue(task.getTaskDesc().equals("this is a description"));
	}
	
@Test
void testTaskIdFails() {
	Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("123456789012", "chore", "do chore")); {
	
	}
}
	
@Test
void testCreateTaskNameFails() {
	Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("12345", "chore name is too long", "do chore")); {
		
	}
}


@Test
void testCreateTaskDescriptionFails() {
	Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("12345", "chore", "description is too long for the task description is too long for the task"));{
		
}
}
}


