package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.time.LocalDate;



class AppointmentTest {

	@Test
	void testCreateAppointmentSuccess() {
		LocalDate currDate = LocalDate.of(2022, 10, 15);
		Appointment appointment = new Appointment("12345", currDate, "This appointment is for something");
		
		assertTrue(appointment != null);
		assertTrue(appointment.getApptId().equals("12345"));
		assertTrue(appointment.getApptDate().equals(currDate.toString()));
		assertTrue(appointment.getApptDesc().equals("This appointment is for something"));
	}
	
	
	@Test
	void testCreateApptIdFails() {
		LocalDate currDate = LocalDate.of(2022, 10, 15);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("01234567890", currDate, "This appointment is for something");
		});
	}
	
	@Test
	void testCreateApptDateFails() {
		LocalDate oldDate = LocalDate.of(2020, 11, 30);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678", oldDate, "This appointment is for something");
		});
	}
	
	@Test
	void testCreateApptDescriptionFails() {
		LocalDate currDate = LocalDate.of(2022, 10, 15);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567", currDate, "This appointment is way too loooooooooooooooooooooooooong");
		});
	}
	
	
	
	
	

}
