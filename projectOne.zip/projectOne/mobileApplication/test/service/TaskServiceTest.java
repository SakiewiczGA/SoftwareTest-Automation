package service;
import model.Task;
import service.TaskService;


import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;


class TaskServiceTest {

	private static TaskService taskService;

	@BeforeAll
	static void setup() {
		taskService = TaskService.getService();
	}
 

	@Test
	void testAddTaskSuccess() {
		Task task = new Task("12345", "do this", "this needs to be done");
		assertTrue(taskService.addTask(task));
		
		Task cachedTask = taskService.getTask(task.getTaskId());
		
		assertTrue(cachedTask != null);
		assertTrue(cachedTask.getTaskId().equals("12345"));
		assertTrue(cachedTask.getTaskName().equals("do this"));
		assertTrue(cachedTask.getTaskDesc().equals("this needs to be done"));
	}


	@Test
	void testAddMultipleTaskSuccess() {
		Task task1 = new Task("12346", "do this", "this needs to be done");
		Task task2 = new Task("12347", "do this", "this needs to be done");
		
		assertTrue(taskService.addTask(task1));
		task1 = taskService.getTask(task1.getTaskId());
		
		assertTrue(task1 != null);
		assertTrue(task1.getTaskId().equals("12346"));
		assertTrue(task1.getTaskName().equals("do this"));
		assertTrue(task1.getTaskDesc().equals("this needs to be done"));
		
		assertTrue(taskService.addTask(task2));
		task2 = taskService.getTask(task2.getTaskId());
		
		assertTrue(task2 != null);
		assertTrue(task2.getTaskId().equals("12347"));
		assertTrue(task2.getTaskName().equals("do this"));
		assertTrue(task2.getTaskDesc().equals("this needs to be done"));
		
	}


	@Test
	void testAddTaskDuplicateIdFail() {
		Task task1 = new Task("54321", "do this", "this needs to be done");
		Task task2 = new Task("54321", "do this", "this needs to be done");
		
		assertTrue(taskService.addTask(task1));
		assertFalse(taskService.addTask(task2));
}

	@Test
	void testGetTaskAndUpdateSuccess() {
		Task task = new Task("12349", "do this", "this needs to be done");	
		assertTrue(taskService.addTask(task));
		
		Task updatedTask = taskService.getTask(task.getTaskId());
		updatedTask.setTaskDesc("new description");
		updatedTask.setTaskName("new name");
		
		updatedTask = taskService.getTask(updatedTask.getTaskId());

		assertTrue(updatedTask.getTaskDesc().equals("new description"));
		assertTrue(updatedTask.getTaskName().equals("new name"));	
	}
	
	@Test
	void testGetTaskAndDeleteSuccess() {
		Task task = new Task("1234", "do this", "this needs to be done");	

		assertTrue(taskService.addTask(task));
		
		task = taskService.getTask(task.getTaskId());
		assertTrue(task != null);
		
		assertTrue(taskService.deleteTask(task.getTaskId()));
		assertTrue(taskService.getTask(task.getTaskId()) == null);
	}
	
	@Test
	void testDeleteInvalidTaskFail() {
		String invalidTaskId = "123";

		assertFalse(taskService.deleteTask(invalidTaskId));
	}


	

}
