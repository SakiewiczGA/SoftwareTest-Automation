package service;
import model.Contact;
import service.ContactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertFalse;
import org.junit.jupiter.api.BeforeAll;



class ContactServiceTest {

private static ContactService contactService;
	
	@BeforeAll
	static void setup() {
		contactService = ContactService.getService();
	}
	
	@Test
	void testAddContactSuccess() {
		Contact contact = new Contact("John", "Doe", "1234567890", "1 Main Street", "12345");	
		assertTrue(contactService.addContact(contact));
		
		Contact getContact = contactService.getContact("12345");
		
		assertTrue(getContact.getContactId().contentEquals(contact.getContactId()));
		assertTrue(getContact.getContactFirstName().contentEquals(contact.getContactFirstName()));
		assertTrue(getContact.getContactLastName().contentEquals(contact.getContactLastName()));
		assertTrue(getContact.getAddress().contentEquals(contact.getAddress()));
		assertTrue(getContact.getPhoneNumber().contentEquals(contact.getPhoneNumber()));
	}
	
	@Test
	void testAddMultipleContactsSuccess() {
		Contact contact1 = new Contact("John", "Doe", "1234567890", "1 Main Street", "1234567");
		Contact contact2 = new Contact("Jane", "Doe", "1234567890", "1 Main Street", "1234578");
		
		assertTrue(contactService.addContact(contact1));
		assertTrue(contactService.addContact(contact2));

	}
	
	@Test
	void testAddContactDuplicateIdFail() {
		Contact contact1 = new Contact("Jane", "Doe", "1234567890", "1 Main Street", "98765");
		Contact contact2 = new Contact("Jane", "Doe", "1234567890", "1 Main Street", "98765");
		
		assertTrue(contactService.addContact(contact1));
		assertFalse(contactService.addContact(contact2));

	}
	
	@Test
	void testGetContactAndUpdateSuccess() {
		Contact contact1 = new Contact("John", "Doe", "1234567890", "1 Main Street", "3456");

		assertTrue(contactService.addContact(contact1));
		Contact updateContact = contactService.getContact(contact1.getContactId());
		
		updateContact.setContactPhoneNumber("8889991111");
		updateContact = contactService.getContact(updateContact.getContactId());
		assertTrue(updateContact.getPhoneNumber().equals("8889991111"));
		
	}
	
	@Test
	void testGetContactAndDeleteSuccess() {
		Contact contact1 = new Contact("John", "Doe", "1234567890", "1 Main Street", "34567");

		assertTrue(contactService.addContact(contact1));
		
		Contact contact2 = contactService.getContact(contact1.getContactId());
		assertTrue(contactService.deleteContact(contact2.getContactId()));

		assertTrue(contactService.getContact(contact2.getContactId()) == null);
		
	}
	
	@Test
	void testDeleteInvalidContactFail() {
		String invalidContactId = "1";

		assertFalse(contactService.deleteContact(invalidContactId));
	}
}
