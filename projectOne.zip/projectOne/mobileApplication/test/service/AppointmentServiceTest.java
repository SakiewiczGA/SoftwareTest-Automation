package service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import static org.junit.Assert.assertFalse;
import model.Appointment;
import service.AppointmentService;
import java.time.LocalDate;


class AppointmentServiceTest {

	
	private static AppointmentService appointmentService;
	
	@BeforeAll
	static void setup() {
		appointmentService = AppointmentService.getService();
	}
	
	@Test
	void testAddAppointmentSuccess() {
		LocalDate newDate = LocalDate.of(2021, 12, 30);
		Appointment appointment = new Appointment("12345", newDate, "Description");
		assertTrue(appointmentService.addAppointment(appointment));
		
		Appointment cachedAppointment = appointmentService.getAppointment(appointment.getApptId());
		
		assertTrue(cachedAppointment != null);
		assertTrue(cachedAppointment.getApptDate().equals(newDate.toString()));
		assertTrue(cachedAppointment.getApptId().equals("12345"));
		assertTrue(cachedAppointment.getApptDesc().equals("Description"));
	}
	
	@Test
	void testAddMultipleAppointmentsSuccess() {
		LocalDate date1 = LocalDate.of(2022, 10, 10);
		LocalDate date2 = LocalDate.of(2022, 11, 10);
		Appointment appointment1 = new Appointment("23456", date1, "Description One");
		Appointment appointment2 = new Appointment("34567", date2, "Description Two");
		
		assertTrue(appointmentService.addAppointment(appointment1));
		appointment1 = appointmentService.getAppointment(appointment1.getApptId());
		
		assertTrue(appointment1 != null);
		assertTrue(appointment1.getApptId().equals("23456"));
		assertTrue(appointment1.getApptDate().equals(date1.toString()));
		assertTrue(appointment1.getApptDesc().equals("Description One"));
		
		assertTrue(appointmentService.addAppointment(appointment2));
		appointment2 = appointmentService.getAppointment(appointment2.getApptId());
		
		assertTrue(appointment2 != null);
		assertTrue(appointment2.getApptId().equals("34567"));
		assertTrue(appointment2.getApptDate().equals(date2.toString()));
		assertTrue(appointment2.getApptDesc().equals("Description Two"));
	}
	
	@Test
	void testAddAppointmentDuplicateIdFail() {
		LocalDate date1 = LocalDate.of(2022, 10, 10);
		LocalDate date2 = LocalDate.of(2022, 11, 10);
		Appointment appointment1 = new Appointment("7890", date1, "Description One");
		Appointment appointment2 = new Appointment("7890", date2, "Description Two");
		
		assertTrue(appointmentService.addAppointment(appointment1));
		assertFalse(appointmentService.addAppointment(appointment2));
	}
	
	@Test
	void testGetAppointmentAndDeleteSuccess() {
		LocalDate date1 = LocalDate.of(2022, 10, 10);
		Appointment appointment = new Appointment("123458", date1, "Description");
		
		assertTrue(appointmentService.addAppointment(appointment));
		
		appointment = appointmentService.getAppointment(appointment.getApptId());
		assertTrue(appointment!=null);
		
		assertTrue(appointmentService.deleteAppointment(appointment.getApptId()));
		assertTrue(appointmentService.getAppointment(appointment.getApptId()) == null);
	}
	
	@Test
	void testDeleteInvalidApptIdFail(){
		String invalidApptId = "9876";
		
		assertFalse(appointmentService.deleteAppointment(invalidApptId));
	}
	

}
