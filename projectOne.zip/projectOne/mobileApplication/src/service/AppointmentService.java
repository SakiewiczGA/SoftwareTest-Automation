package service;

import java.util.HashMap;
import java.util.Map;

import model.Appointment;


public class AppointmentService {
	private static AppointmentService reference = new AppointmentService();
	private final Map<String, Appointment> appointments;
	
	
	AppointmentService(){
		this.appointments = new HashMap<String, Appointment>();
		
	}
	
	//Singleton Appointment service
	public static AppointmentService getService() {
		return reference;
	}
	
	public boolean addAppointment(Appointment appointment) {
		boolean isSuccess = false;
		
		if(!appointments.containsKey(appointment.getApptId())) {
			appointments.put(appointment.getApptId(), appointment);
			isSuccess = true;
		}
		return isSuccess;
	}
	
	public boolean deleteAppointment(String apptId) {
		return appointments.remove(apptId) != null;
	}
	
	public Appointment getAppointment(String apptId) {
		return appointments.get(apptId);
	}
	
	
}
