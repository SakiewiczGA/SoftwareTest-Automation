package model;


public class Contact {
	
    
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	private String contactId;

	
	//constructor

public Contact(String firstName, String lastName, String phoneNumber, String address, String contactId) {
	
	//validate inputs
	boolean isValid = validateInput(contactId, 10);
	
	if(isValid) {
		this.contactId = contactId;
	}
	
	isValid = isValid && setContactFirstName(firstName);
	isValid = isValid && setContactLastName(lastName);
	isValid = isValid && setContactAddress(address);
	isValid = isValid && setContactPhoneNumber(phoneNumber);
	
	if(!isValid) {
		throw new IllegalArgumentException("Invalid input");
	}
}
	
	//accessors
public String getContactFirstName() {
	return firstName;
	}
public String getContactLastName() {
		return lastName;
	}
public String getPhoneNumber() {
		return phoneNumber;
	}
public String getAddress() {
		return address;
	}
public String getContactId() {
		return contactId;
	}
	
	//set variables
	//set first name
	
public boolean setContactFirstName(String firstName) {
	boolean isValid = validateInput(firstName, 10);
	
	if(isValid) {
		this.firstName = firstName;
	}
	return isValid;
		}
	
	
	//last name format same as first
	public boolean setContactLastName(String lastName) {
		boolean isValid = validateInput(lastName, 10);
		
		if(isValid) {
			this.lastName = lastName;
		}
		return isValid;
			}
			
	//Phone Number format
	public boolean setContactPhoneNumber(String phoneNumber) {
			
		boolean IsValid = phoneNumber.matches("\\d{10}");
		
		if(IsValid) {
			this.phoneNumber = phoneNumber;
		}
		return IsValid;
			}
			
	//address format no more than 30 chars 
	public boolean setContactAddress(String address) {
		boolean isValid = validateInput(address, 30);
		
		if(isValid) {
			this.address = address;
		}

		return isValid;
			}
	

	
	//validate input
	private boolean validateInput(String item, int length) {
		return(item != null && item.length() <= length);
	}
	
	
	
}

    


