package model;

public class Task {
	
private String taskId;
private String taskName;
private String taskDesc;


public Task(String taskId, String taskName, String taskDesc) {

	boolean isValid = validateInput(taskId, 10);
		if(isValid) {
		this.taskId = taskId;
	
	}
	isValid = isValid && setTaskName(taskName);
	isValid = isValid && setTaskDesc(taskDesc);
	
	if(!isValid) {
		throw new IllegalArgumentException("Invalid input");
	}

}



public boolean setTaskName(String taskName) {
	boolean isValid = validateInput(taskName, 20);
	if(isValid) {
		this.taskName = taskName;
	}
	return isValid;
}



public boolean setTaskDesc(String taskDesc) {
	boolean isValid = validateInput(taskDesc, 50);
	if(isValid) {
		this.taskDesc = taskDesc;
	}
	return isValid;
	
}


public String getTaskName() {
	return taskName;
}
public String getTaskId() {
	return taskId;
}
public String getTaskDesc() {
	return taskDesc;
}

private boolean validateInput(String item, int length) {
	return(item!=null && item.length() <= length);
}
}
