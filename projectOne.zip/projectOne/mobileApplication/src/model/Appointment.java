package model;

import java.time.LocalDate;

public class Appointment {
	private String apptId;
	private LocalDate apptDate;
	private String apptDesc;
	
		
	public Appointment(String apptId, LocalDate apptDate, String apptDesc) {
		boolean isValid = validateInput(apptId, 10);	
		
		if(isValid) {
			this.apptId = apptId;
		}
		
		isValid = isValid && setApptDate(apptDate);
		isValid = isValid && setApptDesc(apptDesc);
		
		if(!isValid) {
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//set date
	public boolean setApptDate(LocalDate apptDate) {
		boolean isValid = validateDate(apptDate);
		if(isValid) {
			this.apptDate = apptDate;
		}
		return isValid;
	}
	
	//set description
	public boolean setApptDesc(String apptDesc) {
		boolean isValid = validateInput(apptDesc, 50);
		if(isValid) {
			this.apptDesc = apptDesc;
		}
		return isValid;
	}
	
	//input requirements for id and description
	
	private boolean validateInput(String item, int length) {
		return (item != null && item.length() <= length);
	}
	

	
	//input requirement for date - cannot be in the past	
	private boolean validateDate(LocalDate apptDate) {
		LocalDate currDate = LocalDate.now();
		boolean isValid = apptDate.isAfter(currDate);
		if(isValid && currDate != null) {
			this.apptDate = apptDate;
		}
		return isValid;
	}
	
	
	
	public String getApptId() {
		return apptId;
	}
	
	public String getApptDesc() {
		return apptDesc;
	}
	
	
	public String getApptDate() {
		return apptDate.toString();
	}

	
	
}
